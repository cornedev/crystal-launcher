# Empty compiler generated dependencies file for crystal.
# This may be replaced when dependencies are built.
