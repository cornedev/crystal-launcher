CMakeFiles/crystal.dir/crystal_autogen/EWIEGA46WW/qrc_resources.cpp.o: \
 /home/runner/work/mcapi/mcapi/gui/build/crystal_autogen/EWIEGA46WW/qrc_resources.cpp \
 /usr/include/stdc-predef.h
