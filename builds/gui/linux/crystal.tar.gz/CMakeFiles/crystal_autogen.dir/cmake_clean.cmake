file(REMOVE_RECURSE
  "CMakeFiles/crystal_autogen"
  "crystal_autogen/include/ui_console.h"
  "crystal_autogen/include/ui_gui.h"
  "crystal_autogen/mocs_compilation.cpp"
  "crystal_autogen/timestamp"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/crystal_autogen.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
