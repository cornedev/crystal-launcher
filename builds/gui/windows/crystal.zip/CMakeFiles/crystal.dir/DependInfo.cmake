
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "RC"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_RC
  "D:/a/crystal-launcher/crystal-launcher/gui/gfx/icon.rc" "D:/a/crystal-launcher/crystal-launcher/gui/build/CMakeFiles/crystal.dir/gfx/icon.rc.obj"
  )

# Preprocessor definitions for this target.
set(CMAKE_TARGET_DEFINITIONS_RC
  "MINGW_HAS_SECURE_API=1"
  "QT_CONCURRENT_LIB"
  "QT_CORE_LIB"
  "QT_GUI_LIB"
  "QT_NEEDS_QMAIN"
  "QT_NO_DEBUG"
  "QT_WIDGETS_LIB"
  "UNICODE"
  "WIN32"
  "WIN64"
  "WINVER=0x0A00"
  "_ENABLE_EXTENDED_ALIGNED_STORAGE"
  "_UNICODE"
  "_WIN32_WINNT=0x0A00"
  "_WIN64"
  )

# The include file search paths:
set(CMAKE_RC_TARGET_INCLUDE_PATH
  "crystal_autogen/include"
  "D:/a/crystal-launcher/crystal-launcher/gui/runtime/include"
  "D:/a/_temp/msys64/mingw64/include/qt6/QtCore"
  "D:/a/_temp/msys64/mingw64/include/qt6"
  "D:/a/_temp/msys64/mingw64/share/qt6/mkspecs/win32-g++"
  "D:/a/_temp/msys64/mingw64/include/qt6/QtWidgets"
  "D:/a/_temp/msys64/mingw64/include/qt6/QtGui"
  "D:/a/_temp/msys64/mingw64/include"
  "D:/a/_temp/msys64/mingw64/include/qt6/QtConcurrent"
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "D:/a/crystal-launcher/crystal-launcher/api/crystal_auth.cpp" "CMakeFiles/crystal.dir/D_/a/crystal-launcher/crystal-launcher/api/crystal_auth.cpp.obj" "gcc" "CMakeFiles/crystal.dir/D_/a/crystal-launcher/crystal-launcher/api/crystal_auth.cpp.obj.d"
  "D:/a/crystal-launcher/crystal-launcher/api/crystal_discord.cpp" "CMakeFiles/crystal.dir/D_/a/crystal-launcher/crystal-launcher/api/crystal_discord.cpp.obj" "gcc" "CMakeFiles/crystal.dir/D_/a/crystal-launcher/crystal-launcher/api/crystal_discord.cpp.obj.d"
  "D:/a/crystal-launcher/crystal-launcher/api/crystal_fabric.cpp" "CMakeFiles/crystal.dir/D_/a/crystal-launcher/crystal-launcher/api/crystal_fabric.cpp.obj" "gcc" "CMakeFiles/crystal.dir/D_/a/crystal-launcher/crystal-launcher/api/crystal_fabric.cpp.obj.d"
  "D:/a/crystal-launcher/crystal-launcher/api/crystal_http.cpp" "CMakeFiles/crystal.dir/D_/a/crystal-launcher/crystal-launcher/api/crystal_http.cpp.obj" "gcc" "CMakeFiles/crystal.dir/D_/a/crystal-launcher/crystal-launcher/api/crystal_http.cpp.obj.d"
  "D:/a/crystal-launcher/crystal-launcher/api/crystal_java.cpp" "CMakeFiles/crystal.dir/D_/a/crystal-launcher/crystal-launcher/api/crystal_java.cpp.obj" "gcc" "CMakeFiles/crystal.dir/D_/a/crystal-launcher/crystal-launcher/api/crystal_java.cpp.obj.d"
  "D:/a/crystal-launcher/crystal-launcher/api/crystal_process.cpp" "CMakeFiles/crystal.dir/D_/a/crystal-launcher/crystal-launcher/api/crystal_process.cpp.obj" "gcc" "CMakeFiles/crystal.dir/D_/a/crystal-launcher/crystal-launcher/api/crystal_process.cpp.obj.d"
  "D:/a/crystal-launcher/crystal-launcher/api/crystal_vanilla.cpp" "CMakeFiles/crystal.dir/D_/a/crystal-launcher/crystal-launcher/api/crystal_vanilla.cpp.obj" "gcc" "CMakeFiles/crystal.dir/D_/a/crystal-launcher/crystal-launcher/api/crystal_vanilla.cpp.obj.d"
  "D:/a/crystal-launcher/crystal-launcher/gui/console.cpp" "CMakeFiles/crystal.dir/console.cpp.obj" "gcc" "CMakeFiles/crystal.dir/console.cpp.obj.d"
  "D:/a/crystal-launcher/crystal-launcher/gui/build/crystal_autogen/EWIEGA46WW/qrc_resources.cpp" "CMakeFiles/crystal.dir/crystal_autogen/EWIEGA46WW/qrc_resources.cpp.obj" "gcc" "CMakeFiles/crystal.dir/crystal_autogen/EWIEGA46WW/qrc_resources.cpp.obj.d"
  "D:/a/crystal-launcher/crystal-launcher/gui/build/crystal_autogen/mocs_compilation.cpp" "CMakeFiles/crystal.dir/crystal_autogen/mocs_compilation.cpp.obj" "gcc" "CMakeFiles/crystal.dir/crystal_autogen/mocs_compilation.cpp.obj.d"
  "D:/a/crystal-launcher/crystal-launcher/gui/gui.cpp" "CMakeFiles/crystal.dir/gui.cpp.obj" "gcc" "CMakeFiles/crystal.dir/gui.cpp.obj.d"
  "D:/a/crystal-launcher/crystal-launcher/gui/main.cpp" "CMakeFiles/crystal.dir/main.cpp.obj" "gcc" "CMakeFiles/crystal.dir/main.cpp.obj.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
