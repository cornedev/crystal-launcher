set(__QT_DEPLOY_TARGET_crystal_FILE /Users/runner/work/mcapi/mcapi/gui/build/crystal.app/Contents/MacOS/crystal)
set(__QT_DEPLOY_TARGET_crystal_TYPE EXECUTABLE)
