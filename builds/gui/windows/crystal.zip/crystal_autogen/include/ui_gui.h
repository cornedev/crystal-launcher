/********************************************************************************
** Form generated from reading UI file 'gui.ui'
**
** Created by: Qt User Interface Compiler version 6.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GUI_H
#define UI_GUI_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_gui
{
public:
    QStackedWidget *pages;
    QWidget *login;
    QPushButton *offlinebutton;
    QLabel *logologin;
    QLabel *loginbackground;
    QPushButton *loginmicrosoftbutton;
    QLabel *copyrightnote;
    QPushButton *logincancelbutton;
    QCheckBox *latestlogin;
    QWidget *launcher;
    QLabel *version;
    QLabel *username;
    QLineEdit *usernameinput;
    QComboBox *versionbox;
    QPushButton *startbutton;
    QPushButton *stopbutton;
    QLabel *logo;
    QLabel *launcherbackground;
    QComboBox *loaderbox;
    QLabel *loader;
    QPushButton *consolebutton;
    QPushButton *backbutton;

    void setupUi(QWidget *gui)
    {
        if (gui->objectName().isEmpty())
            gui->setObjectName("gui");
        gui->resize(725, 676);
        gui->setMinimumSize(QSize(725, 676));
        gui->setMaximumSize(QSize(725, 676));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/gfx/crystal_gui.png"), QSize(), QIcon::Mode::Normal, QIcon::State::Off);
        gui->setWindowIcon(icon);
        pages = new QStackedWidget(gui);
        pages->setObjectName("pages");
        pages->setGeometry(QRect(0, 0, 725, 676));
        pages->setMinimumSize(QSize(725, 676));
        pages->setMaximumSize(QSize(725, 676));
        login = new QWidget();
        login->setObjectName("login");
        offlinebutton = new QPushButton(login);
        offlinebutton->setObjectName("offlinebutton");
        offlinebutton->setGeometry(QRect(480, 120, 141, 41));
        logologin = new QLabel(login);
        logologin->setObjectName("logologin");
        logologin->setGeometry(QRect(460, 30, 180, 60));
        logologin->setPixmap(QPixmap(QString::fromUtf8(":/gfx/crystal_logo.png")));
        loginbackground = new QLabel(login);
        loginbackground->setObjectName("loginbackground");
        loginbackground->setGeometry(QRect(0, 0, 725, 676));
        loginbackground->setPixmap(QPixmap(QString::fromUtf8(":/gfx/crystal_background_login.png")));
        loginmicrosoftbutton = new QPushButton(login);
        loginmicrosoftbutton->setObjectName("loginmicrosoftbutton");
        loginmicrosoftbutton->setEnabled(true);
        loginmicrosoftbutton->setGeometry(QRect(460, 180, 181, 41));
        loginmicrosoftbutton->setAutoFillBackground(false);
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/gfx/microsoft.png"), QSize(), QIcon::Mode::Normal, QIcon::State::Off);
        loginmicrosoftbutton->setIcon(icon1);
        copyrightnote = new QLabel(login);
        copyrightnote->setObjectName("copyrightnote");
        copyrightnote->setGeometry(QRect(465, 640, 211, 20));
        logincancelbutton = new QPushButton(login);
        logincancelbutton->setObjectName("logincancelbutton");
        logincancelbutton->setEnabled(true);
        logincancelbutton->setGeometry(QRect(495, 270, 111, 41));
        logincancelbutton->setAutoDefault(false);
        logincancelbutton->setFlat(false);
        latestlogin = new QCheckBox(login);
        latestlogin->setObjectName("latestlogin");
        latestlogin->setGeometry(QRect(500, 240, 161, 21));
        pages->addWidget(login);
        loginbackground->raise();
        offlinebutton->raise();
        logologin->raise();
        loginmicrosoftbutton->raise();
        copyrightnote->raise();
        logincancelbutton->raise();
        latestlogin->raise();
        launcher = new QWidget();
        launcher->setObjectName("launcher");
        version = new QLabel(launcher);
        version->setObjectName("version");
        version->setGeometry(QRect(155, 200, 81, 16));
        username = new QLabel(launcher);
        username->setObjectName("username");
        username->setGeometry(QRect(147, 90, 61, 16));
        usernameinput = new QLineEdit(launcher);
        usernameinput->setObjectName("usernameinput");
        usernameinput->setGeometry(QRect(100, 110, 151, 24));
        usernameinput->setClearButtonEnabled(false);
        versionbox = new QComboBox(launcher);
        versionbox->setObjectName("versionbox");
        versionbox->setGeometry(QRect(100, 220, 151, 24));
        versionbox->setEditable(false);
        versionbox->setSizeAdjustPolicy(QComboBox::SizeAdjustPolicy::AdjustToContentsOnFirstShow);
        startbutton = new QPushButton(launcher);
        startbutton->setObjectName("startbutton");
        startbutton->setGeometry(QRect(80, 290, 191, 51));
        stopbutton = new QPushButton(launcher);
        stopbutton->setObjectName("stopbutton");
        stopbutton->setGeometry(QRect(80, 360, 191, 51));
        logo = new QLabel(launcher);
        logo->setObjectName("logo");
        logo->setGeometry(QRect(85, 18, 180, 60));
        logo->setPixmap(QPixmap(QString::fromUtf8(":/gfx/crystal_logo.png")));
        launcherbackground = new QLabel(launcher);
        launcherbackground->setObjectName("launcherbackground");
        launcherbackground->setGeometry(QRect(0, 0, 725, 676));
        launcherbackground->setPixmap(QPixmap(QString::fromUtf8(":/gfx/crystal_background_launcher.png")));
        loaderbox = new QComboBox(launcher);
        loaderbox->setObjectName("loaderbox");
        loaderbox->setGeometry(QRect(100, 160, 151, 24));
        loaderbox->setEditable(false);
        loaderbox->setSizeAdjustPolicy(QComboBox::SizeAdjustPolicy::AdjustToContentsOnFirstShow);
        loader = new QLabel(launcher);
        loader->setObjectName("loader");
        loader->setGeometry(QRect(156, 140, 81, 16));
        consolebutton = new QPushButton(launcher);
        consolebutton->setObjectName("consolebutton");
        consolebutton->setGeometry(QRect(80, 560, 191, 41));
        backbutton = new QPushButton(launcher);
        backbutton->setObjectName("backbutton");
        backbutton->setGeometry(QRect(100, 620, 151, 41));
        pages->addWidget(launcher);
        launcherbackground->raise();
        version->raise();
        username->raise();
        usernameinput->raise();
        versionbox->raise();
        startbutton->raise();
        stopbutton->raise();
        logo->raise();
        loaderbox->raise();
        loader->raise();
        consolebutton->raise();
        backbutton->raise();

        retranslateUi(gui);

        pages->setCurrentIndex(1);
        logincancelbutton->setDefault(false);
        versionbox->setCurrentIndex(-1);
        loaderbox->setCurrentIndex(-1);


        QMetaObject::connectSlotsByName(gui);
    } // setupUi

    void retranslateUi(QWidget *gui)
    {
        gui->setWindowTitle(QCoreApplication::translate("gui", "crystal launcher", nullptr));
        offlinebutton->setText(QCoreApplication::translate("gui", "Play offline", nullptr));
        logologin->setText(QString());
        loginbackground->setText(QString());
        loginmicrosoftbutton->setText(QCoreApplication::translate("gui", "  Sign in with Microsoft", nullptr));
        copyrightnote->setText(QCoreApplication::translate("gui", "Copyright (c) 2025-2026 cornedev", nullptr));
        logincancelbutton->setText(QCoreApplication::translate("gui", "Cancel login", nullptr));
        latestlogin->setText(QCoreApplication::translate("gui", "Use latest login", nullptr));
        version->setText(QCoreApplication::translate("gui", "Version  ", nullptr));
        username->setText(QCoreApplication::translate("gui", "Username", nullptr));
        startbutton->setText(QCoreApplication::translate("gui", "Start", nullptr));
        stopbutton->setText(QCoreApplication::translate("gui", "Stop", nullptr));
        logo->setText(QString());
        launcherbackground->setText(QString());
        loader->setText(QCoreApplication::translate("gui", "Loader  ", nullptr));
        consolebutton->setText(QCoreApplication::translate("gui", "Console", nullptr));
        backbutton->setText(QCoreApplication::translate("gui", "Back", nullptr));
    } // retranslateUi

};

namespace Ui {
    class gui: public Ui_gui {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GUI_H
