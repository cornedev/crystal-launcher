
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/Users/runner/work/mcapi/mcapi/api/crystal_auth.cpp" "CMakeFiles/crystal.dir/Users/runner/work/mcapi/mcapi/api/crystal_auth.cpp.o" "gcc" "CMakeFiles/crystal.dir/Users/runner/work/mcapi/mcapi/api/crystal_auth.cpp.o.d"
  "/Users/runner/work/mcapi/mcapi/api/crystal_fabric.cpp" "CMakeFiles/crystal.dir/Users/runner/work/mcapi/mcapi/api/crystal_fabric.cpp.o" "gcc" "CMakeFiles/crystal.dir/Users/runner/work/mcapi/mcapi/api/crystal_fabric.cpp.o.d"
  "/Users/runner/work/mcapi/mcapi/api/crystal_http.cpp" "CMakeFiles/crystal.dir/Users/runner/work/mcapi/mcapi/api/crystal_http.cpp.o" "gcc" "CMakeFiles/crystal.dir/Users/runner/work/mcapi/mcapi/api/crystal_http.cpp.o.d"
  "/Users/runner/work/mcapi/mcapi/api/crystal_java.cpp" "CMakeFiles/crystal.dir/Users/runner/work/mcapi/mcapi/api/crystal_java.cpp.o" "gcc" "CMakeFiles/crystal.dir/Users/runner/work/mcapi/mcapi/api/crystal_java.cpp.o.d"
  "/Users/runner/work/mcapi/mcapi/api/crystal_process.cpp" "CMakeFiles/crystal.dir/Users/runner/work/mcapi/mcapi/api/crystal_process.cpp.o" "gcc" "CMakeFiles/crystal.dir/Users/runner/work/mcapi/mcapi/api/crystal_process.cpp.o.d"
  "/Users/runner/work/mcapi/mcapi/api/crystal_vanilla.cpp" "CMakeFiles/crystal.dir/Users/runner/work/mcapi/mcapi/api/crystal_vanilla.cpp.o" "gcc" "CMakeFiles/crystal.dir/Users/runner/work/mcapi/mcapi/api/crystal_vanilla.cpp.o.d"
  "/Users/runner/work/mcapi/mcapi/gui/console.cpp" "CMakeFiles/crystal.dir/console.cpp.o" "gcc" "CMakeFiles/crystal.dir/console.cpp.o.d"
  "/Users/runner/work/mcapi/mcapi/gui/build/crystal_autogen/EWIEGA46WW/qrc_resources.cpp" "CMakeFiles/crystal.dir/crystal_autogen/EWIEGA46WW/qrc_resources.cpp.o" "gcc" "CMakeFiles/crystal.dir/crystal_autogen/EWIEGA46WW/qrc_resources.cpp.o.d"
  "/Users/runner/work/mcapi/mcapi/gui/build/crystal_autogen/mocs_compilation.cpp" "CMakeFiles/crystal.dir/crystal_autogen/mocs_compilation.cpp.o" "gcc" "CMakeFiles/crystal.dir/crystal_autogen/mocs_compilation.cpp.o.d"
  "/Users/runner/work/mcapi/mcapi/gui/gui.cpp" "CMakeFiles/crystal.dir/gui.cpp.o" "gcc" "CMakeFiles/crystal.dir/gui.cpp.o.d"
  "/Users/runner/work/mcapi/mcapi/gui/main.cpp" "CMakeFiles/crystal.dir/main.cpp.o" "gcc" "CMakeFiles/crystal.dir/main.cpp.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
