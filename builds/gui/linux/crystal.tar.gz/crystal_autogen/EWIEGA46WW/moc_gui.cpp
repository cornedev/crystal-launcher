/****************************************************************************
** Meta object code from reading C++ file 'gui.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.4.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../gui.h"
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'gui.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.4.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
namespace {
struct qt_meta_stringdata_gui_t {
    uint offsetsAndSizes[30];
    char stringdata0[4];
    char stringdata1[23];
    char stringdata2[1];
    char stringdata3[7];
    char stringdata4[24];
    char stringdata5[8];
    char stringdata6[19];
    char stringdata7[3];
    char stringdata8[21];
    char stringdata9[25];
    char stringdata10[6];
    char stringdata11[23];
    char stringdata12[22];
    char stringdata13[32];
    char stringdata14[29];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_gui_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_gui_t qt_meta_stringdata_gui = {
    {
        QT_MOC_LITERAL(0, 3),  // "gui"
        QT_MOC_LITERAL(4, 22),  // "on_loadercombo_changed"
        QT_MOC_LITERAL(27, 0),  // ""
        QT_MOC_LITERAL(28, 6),  // "loader"
        QT_MOC_LITERAL(35, 23),  // "on_versioncombo_changed"
        QT_MOC_LITERAL(59, 7),  // "version"
        QT_MOC_LITERAL(67, 18),  // "on_oscombo_changed"
        QT_MOC_LITERAL(86, 2),  // "os"
        QT_MOC_LITERAL(89, 20),  // "on_archcombo_changed"
        QT_MOC_LITERAL(110, 24),  // "on_usernameinput_changed"
        QT_MOC_LITERAL(135, 5),  // "input"
        QT_MOC_LITERAL(141, 22),  // "on_startbutton_clicked"
        QT_MOC_LITERAL(164, 21),  // "on_stopbutton_clicked"
        QT_MOC_LITERAL(186, 31),  // "on_loginmicrosoftbutton_clicked"
        QT_MOC_LITERAL(218, 28)   // "on_logincancelbutton_clicked"
    },
    "gui",
    "on_loadercombo_changed",
    "",
    "loader",
    "on_versioncombo_changed",
    "version",
    "on_oscombo_changed",
    "os",
    "on_archcombo_changed",
    "on_usernameinput_changed",
    "input",
    "on_startbutton_clicked",
    "on_stopbutton_clicked",
    "on_loginmicrosoftbutton_clicked",
    "on_logincancelbutton_clicked"
};
#undef QT_MOC_LITERAL
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_gui[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,   68,    2, 0x08,    1 /* Private */,
       4,    1,   71,    2, 0x08,    3 /* Private */,
       6,    1,   74,    2, 0x08,    5 /* Private */,
       8,    1,   77,    2, 0x08,    7 /* Private */,
       9,    1,   80,    2, 0x08,    9 /* Private */,
      11,    0,   83,    2, 0x08,   11 /* Private */,
      12,    0,   84,    2, 0x08,   12 /* Private */,
      13,    0,   85,    2, 0x08,   13 /* Private */,
      14,    0,   86,    2, 0x08,   14 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::QString,    7,
    QMetaType::Void, QMetaType::QString,    7,
    QMetaType::Void, QMetaType::QString,   10,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject gui::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_gui.offsetsAndSizes,
    qt_meta_data_gui,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_gui_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<gui, std::true_type>,
        // method 'on_loadercombo_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'on_versioncombo_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'on_oscombo_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'on_archcombo_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'on_usernameinput_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'on_startbutton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_stopbutton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_loginmicrosoftbutton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_logincancelbutton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void gui::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<gui *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_loadercombo_changed((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 1: _t->on_versioncombo_changed((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 2: _t->on_oscombo_changed((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 3: _t->on_archcombo_changed((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 4: _t->on_usernameinput_changed((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 5: _t->on_startbutton_clicked(); break;
        case 6: _t->on_stopbutton_clicked(); break;
        case 7: _t->on_loginmicrosoftbutton_clicked(); break;
        case 8: _t->on_logincancelbutton_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject *gui::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *gui::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_gui.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int gui::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 9;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
