set(__QT_DEPLOY_TARGET_crystal_FILE D:/a/crystal-launcher/crystal-launcher/gui/build/crystal.exe)
set(__QT_DEPLOY_TARGET_crystal_TYPE EXECUTABLE)
set(__QT_DEPLOY_TARGET_crystal_RUNTIME_DLLS D:/a/_temp/msys64/mingw64/bin/Qt6Widgets.dll;D:/a/_temp/msys64/mingw64/bin/Qt6Concurrent.dll;D:/a/_temp/msys64/mingw64/bin/Qt6Gui.dll;D:/a/_temp/msys64/mingw64/bin/Qt6Core.dll)
