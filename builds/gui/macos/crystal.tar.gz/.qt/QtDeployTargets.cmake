set(__QT_DEPLOY_TARGETS "crystal")
set(__QT_DEPLOY_TARGET_crystal_FILE /Users/runner/work/crystal-launcher/crystal-launcher/gui/build/crystal.app/Contents/MacOS/crystal)
set(__QT_DEPLOY_TARGET_crystal_TYPE EXECUTABLE)
