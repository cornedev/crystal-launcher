file(REMOVE_RECURSE
  "CMakeFiles/crystal.dir/link.d"
  "CMakeFiles/crystal_autogen.dir/AutogenUsed.txt"
  "CMakeFiles/crystal_autogen.dir/ParseCache.txt"
  "crystal_autogen"
  "CMakeFiles/crystal.dir/console.cpp.o"
  "CMakeFiles/crystal.dir/console.cpp.o.d"
  "CMakeFiles/crystal.dir/crystal_autogen/EWIEGA46WW/qrc_resources.cpp.o"
  "CMakeFiles/crystal.dir/crystal_autogen/EWIEGA46WW/qrc_resources.cpp.o.d"
  "CMakeFiles/crystal.dir/crystal_autogen/mocs_compilation.cpp.o"
  "CMakeFiles/crystal.dir/crystal_autogen/mocs_compilation.cpp.o.d"
  "CMakeFiles/crystal.dir/gui.cpp.o"
  "CMakeFiles/crystal.dir/gui.cpp.o.d"
  "CMakeFiles/crystal.dir/home/runner/work/mcapi/mcapi/api/crystal_auth.cpp.o"
  "CMakeFiles/crystal.dir/home/runner/work/mcapi/mcapi/api/crystal_auth.cpp.o.d"
  "CMakeFiles/crystal.dir/home/runner/work/mcapi/mcapi/api/crystal_fabric.cpp.o"
  "CMakeFiles/crystal.dir/home/runner/work/mcapi/mcapi/api/crystal_fabric.cpp.o.d"
  "CMakeFiles/crystal.dir/home/runner/work/mcapi/mcapi/api/crystal_http.cpp.o"
  "CMakeFiles/crystal.dir/home/runner/work/mcapi/mcapi/api/crystal_http.cpp.o.d"
  "CMakeFiles/crystal.dir/home/runner/work/mcapi/mcapi/api/crystal_java.cpp.o"
  "CMakeFiles/crystal.dir/home/runner/work/mcapi/mcapi/api/crystal_java.cpp.o.d"
  "CMakeFiles/crystal.dir/home/runner/work/mcapi/mcapi/api/crystal_process.cpp.o"
  "CMakeFiles/crystal.dir/home/runner/work/mcapi/mcapi/api/crystal_process.cpp.o.d"
  "CMakeFiles/crystal.dir/home/runner/work/mcapi/mcapi/api/crystal_vanilla.cpp.o"
  "CMakeFiles/crystal.dir/home/runner/work/mcapi/mcapi/api/crystal_vanilla.cpp.o.d"
  "CMakeFiles/crystal.dir/main.cpp.o"
  "CMakeFiles/crystal.dir/main.cpp.o.d"
  "crystal"
  "crystal.pdb"
  "crystal_autogen/EWIEGA46WW/qrc_resources.cpp"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/crystal.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
