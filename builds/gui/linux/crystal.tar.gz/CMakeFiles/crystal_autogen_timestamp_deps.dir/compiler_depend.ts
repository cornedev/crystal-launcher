# CMAKE generated file: DO NOT EDIT!
# Timestamp file for custom commands dependencies management for crystal_autogen_timestamp_deps.
